﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace studybaselaba1
{
    public class Admin
    {
        public static Frame MainFrame { get; set; }
    }
}
